#pragma once

class INoise
{
public:

private:
};
